import UIKit
//Convertire valore in decimale, binario,esadecimale,ottale
//valore decimale.
//inseire in Radix la base da ottenere tipo 10,2,8,16
/*
 Elenco conversioni:
 Da decimale:
    1)binario
    2) ottale:
    3) esadecimale:
 Da Binario:
    4) decimale:
    5) ottale:
    6) esadecimale:
 Da Ottale:
    7) decimale:
    8) binario:
    9) eadecimale:
 Da Esadecimale:
    10) decimale:
    11) binario:
    12) ottale:
 */

//Valori da base 10
//1:
var num = 99
print("Valore Decimale:",num)
let result1 = String(num,radix: 2)
print("Da decimale e binario:",result1)
//2:
var result2 = Int(String(num,radix: 8))
print( "Da decimale a ottale:",result2!)
//3:
var result3 = String(Int(num),radix: 16)
print("Da Decimale a Esadecimale:",result3.uppercased())
print("\n************************************\n")
//Valori Con base binario
var valueB = "10101010"
print("Valore Binario:",valueB)
//4:
let result4 = Int(String(valueB),radix: 2)
print("Da Binario a decimale:",result4!)
//5:
var result5 = String(Int(String(valueB),radix: 2)!,radix: 8)
print("Da binario a ottale:",result5)
//6:
var result6 = String(Int(String(valueB),radix: 2)!,radix: 16)
print("Da Binario a Esadecimale:",result6.uppercased())
print("\n************************************\n")
//Da ottale
var valueO = 555
print("Valore Ottale:",valueO)
//7
var result7 = Int(String(valueO),radix: 8)
print("Da ottale e Decimale:",result7!)
//8
var result8 = String(Int(String(valueO),radix: 8)!,radix: 2)
print("Da Ottale a Binario:",result8)
//9:
var result9 = String(Int(String(valueO),radix: 8)!,radix: 16)
print("Da Ottale a Esadecimale:",result9.uppercased())
print("\n************************************\n")
//Da esadecimale :
var valoreE = "9A"
print("Valore Esadecimale:",valoreE)
//result10
var result10 = Int(valoreE,radix:16)
print("Da Esadecimale a Decimale:",result10!)
//result11
var result11 = String(Int(String(valoreE),radix: 16)!,radix: 2)
print("Da Esadecmale a Binario:",result11)
//result12
var result12 = Int(String(Int(valoreE,radix: 16)!,radix: 8))!
print("Da Esadecimale a Ottale:",result12)
